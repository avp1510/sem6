#Fibonacci
# fn = (fn-1) + (fn-2)
#0 1 1 2 3 5 8 13


#iterative



def fiboit(ip):
    prevnum = 0
    currnum = 1
    for i in range(1,ip):
        prevPrevnum = prevnum
        prevnum = currnum
        currnum = prevnum + prevPrevnum
    
    return currnum

def fiborec(ip):
    if ip == 0:
        return ip
    elif ip == 1:
        return ip
    else:
        return fiborec(ip-2) + fiborec(ip-1)


if __name__ == "__main__":

    ip = int(input('For nth term to be found enter the n = '))
    print(f"Using recursion value of fib({ip}) is {fiborec(ip)}")

    print(f"Using iteration value of fib({ip}) is {fiboit(ip)}")