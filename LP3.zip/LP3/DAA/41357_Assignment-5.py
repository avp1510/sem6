class sort: 
    def partition(self,per,bot,top): 
        i=(bot-1) 
        piv=per[top] 
        for j in range(bot,top): 
            if per[j]<piv: 
                i += 1 
                temp = per[i] 
                per[i]=per[j] 
                per[j]=temp 
        tem=per[i+1] 
        per[i+1]=per[top] 
        per[top]=tem 
        return i+1 
    def quick_sort(self,per,bot,top): 
        if bot<top: 
            parti=self.partition(per,bot,top) 
            self.quick_sort(per,bot,parti-1) 
            self.quick_sort(per,parti+1,top) 
        return per 
N=int(input("\nEnter size of data: ")) 
print("\nEnter data: ") 
data=[] 
for i in range(N): 
    i=input() 
    data.append(i) 
s=sort() 
s.quick_sort(data,0,N-1) 
print("\nThe data in sorted order is: ", data) 