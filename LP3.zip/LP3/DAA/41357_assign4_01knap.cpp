#include <bits/stdc++.h>
using namespace std;

int knap(int mx_wt, vector<int> &wt, vector<int> &cst) {
    if (accumulate(wt.begin(), wt.end(), 0) <= mx_wt) {
        return accumulate(cst.begin(), cst.end(), 0);
    }

    int n = wt.size();
    vector<vector<int>> dp(n + 1, vector<int>(mx_wt + 1, 0));
    for (int i = 1; i < n + 1; i++) {
        for (int j = 1; j < mx_wt + 1; j++) {
            if (0 <= j - wt[i - 1])
                dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - wt[i - 1]] + cst[i - 1]);
            else
                dp[i][j] = dp[i - 1][j];
        }
    }

    return dp[n][mx_wt];
}

int main() {
    int n{0}, mx_wt{0};
    cout << "Enter number of elements: ";
    cin >> n;
    cout << "Enter maximum weight of bag: ";
    cin >> mx_wt;
    vector<int> cst(n);
    vector<int> wt(n);
    for (int i = 0; i < n; i++) {
        cout << "Enter weight and cost of element " << i + 1 << ": ";
        cin >> wt[i] >> cst[i];
    }
    cout << "Maximum cost of elements that can be taken are: " << knap(mx_wt, wt, cst) << endl;
    return 0;
}