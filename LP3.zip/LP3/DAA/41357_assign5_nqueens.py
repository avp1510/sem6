def prnt(bd):
    for i in bd:
        for j in i:
            print(j, " ", end="")
        print()


def isSafe(fwsl, bksl, rwck, row, col, size):
    if(rwck[row] or fwsl[row+col] or bksl[row-col+(size-1)]):
        return False
    return True


def sol(bd, fwsl, bksl, rwck, stcl, size):
    if stcl >= size:
        return True

    for row in range(size):
        if isSafe(fwsl, bksl, rwck, row, stcl, size):
            bd[row][stcl] = 1
            rwck[row] = True
            fwsl[row+stcl] = True
            bksl[row-stcl+(size-1)] = True

            if sol(bd, fwsl, bksl, rwck, stcl+1, size):
                return True

            else:
                bd[row][stcl] = 0
                rwck[row] = False
                fwsl[row+stcl] = False
                bksl[row-stcl+(size-1)] = False

    return False


n = int(input("Enter size of board: "))
bd = list()

for i in range(n):
    l = list()
    for j in range(n):
        l.append(0)
    bd.append(l)

x = 2 * n - 1
fwsl = [False] * x
bksl = [False] * x
rwck = [False] * n

sol(bd, fwsl, bksl, rwck, 0, n)

prnt(bd)
