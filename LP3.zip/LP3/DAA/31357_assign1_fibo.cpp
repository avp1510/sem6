#include <bits/stdc++.h>
using namespace std;

int fibo_r(int n) {
    if (n < 1)
        return -1;

    if (n == 1)
        return 1;
    if (n == 2)
        return 1;
    return fibo_r(n - 1) + fibo_r(n - 2);
}

int fibo_nr(int n) {
    if (n < 1)
        return -1;

    int a{1}, b{1};
    for (int i = 3; i <= n; i++) {
        b = b + a;
        a = b - a;
    }
    return b;
}

int main() {

    char c;
    do {
        cout << "\n\n******* Menu *******\n"
             << "1. Recursive Fibonacci\n"
             << "2. Non recursive Fibonacci\n"
             << "3. Exit\n"
             << ">>> ";
        cin >> c;
        switch (c) {
        case '1': {
            int n;
            cout << "\nEnter a number: ";
            cin >> n;
            cout << "Fibonacci number is: " << fibo_r(n) << endl;
            break;
        }
        case '2': {
            int n;
            cout << "\nEnter a number: ";
            cin >> n;
            cout << "Fibonacci number is: " << fibo_nr(n) << endl;
            break;
        }
        case '3': {
            cout << "\nThank You!!!" << endl;
            break;
        }
        default:
            cout << "\nEnter a valid choice" << endl;
        }
    } while (c != '3');
    return 0;
}