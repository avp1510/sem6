#include <bits/stdc++.h>
using namespace std;

int knap(int mx_wt, vector<int> &wt, vector<int> &cst) {
    if (accumulate(wt.begin(), wt.end(), 0) <= mx_wt) {
        return accumulate(cst.begin(), cst.end(), 0);
    }

    vector<pair<int, int>> arr(wt.size()); // pair -> cost, weight
    for (int i = 0; i < wt.size(); i++) {
        arr[i] = {cst[i], wt[i]};
    }
    sort(arr.begin(), arr.end(), [](auto a, auto b) { return 1.0 * a.first / a.second > 1.0 * b.first / b.second; });
    int mx_cst{0}, cur_wt{0};
    int i = 0;
    while (i < wt.size()) {
        if (cur_wt + arr[i].second <= mx_wt) {
            mx_cst += arr[i].first;
            cur_wt += arr[i].second;
        } else {
            mx_cst += 1.0 * arr[i].first / arr[i].second * (mx_wt - cur_wt);
            cur_wt = mx_wt;
            break;
        }
        i++;
    }

    return mx_cst;
}

int main() {
    int n{0}, mx_wt{0};
    cout << "Enter number of elements: ";
    cin >> n;
    cout << "Enter maximum weight of bag: ";
    cin >> mx_wt;
    vector<int> cst(n);
    vector<int> wt(n);
    for (int i = 0; i < n; i++) {
        cout << "Enter weight and cost of element " << i + 1 << ": ";
        cin >> wt[i] >> cst[i];
    }
    cout << "Maximum cost of elements that can be taken are: " << knap(mx_wt, wt, cst) << endl;
    return 0;
}